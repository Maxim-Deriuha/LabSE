/*
 * CBasicSkreen.h
 *
 *  Created on: 16 ���. 2019 �.
 *      Author: Acer
 #pragma once*/

#pragma once
#define CBASICSKREEN_H_

#include "CAgent.h"
#include <iostream>

using std::cout;
using std::endl;

class CBasicSkreen {

protected:

	virtual void ShowHeader();
	virtual void ShowContent();
	virtual void ShowFooter();

public:

	CAgent agent;

	void Display(const CAgent& agent);


	 virtual ~CBasicSkreen();
};
