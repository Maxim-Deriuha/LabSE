//============================================================================
// Name        : deriuha3.cpp
// Author      : deriuha
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

#include "CAgent.h"
#include "CSkreen.h"
#include "CSkreen2.h"
#include <stdio.h>
#include "CBasicSkreen.h"
int main()
{
	cout << "lab 3" << endl;
	CAgent agent(2, 13, "James bond2", 2);
	CSkreen skreen;
	CSkreen2 view2;
   // skreen.ScreenAgent(agent);
//	view2.GraphScreen(agent);

	//skreen.Display();
	view2.Display(agent);

	return 0;
}
