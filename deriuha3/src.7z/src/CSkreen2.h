/*
 * CSkreen2.h
 *
 *  Created on: 11 ���. 2019 �.
 *      Author: Acer
 */


#define CSKREEN2_H_

#include "CAgent.h"
#include <iostream>
#include "CBasicSkreen.h"
#pragma once
class CSkreen2:public CBasicSkreen
{
public:

	CAgent agent;

    void ShowHeader();
    void ShowContent();
    void ShowFooter();
	void GraphScreen(const CAgent& agent);
	void ScreenField(unsigned int, string, unsigned int, unsigned int, string, unsigned int);

	CSkreen2(const CAgent& agent);

	CSkreen2();
	~CSkreen2();


};
