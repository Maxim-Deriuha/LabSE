/*
 * CBasicSkreen.cpp
 *
 *  Created on: 16 ���. 2019 �.
 *      Author: Acer
 */

#include "CBasicSkreen.h"



void CBasicSkreen::ShowHeader() {

	cout << "agent: " << endl << endl;
}

void CBasicSkreen::ShowContent() {

	cout << "agent: " << endl << endl;
		cout << "unique_identifier = " << agent.unique_identifier << endl;
		cout << "nickname_length= " << agent.getNicknameLength() << endl;
		cout << "nickname= " << agent.getNickname() << endl;
		cout << "type_specialty= " << agent.type_specialty << endl;
		cout << "nick_dlin : " << agent.CheckSum() << endl;
}

void CBasicSkreen::ShowFooter() {
	cout << "view: base" << endl << endl;
}

void CBasicSkreen::Display(const CAgent& agent) {

	ShowHeader();
	ShowContent();
	ShowFooter();
}




CBasicSkreen::~CBasicSkreen()
{
}
