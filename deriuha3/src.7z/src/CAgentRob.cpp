/*
 * CAgentRob.cpp
 *
 *  Created on: 16 ���. 2019 �.
 *      Author: Acer
 */

#include "CAgentRob.h"

CAgentRob::CAgentRob() {
	// TODO Auto-generated constructor stub

}

CAgentRob::~CAgentRob() {
	// TODO Auto-generated destructor stub
}

