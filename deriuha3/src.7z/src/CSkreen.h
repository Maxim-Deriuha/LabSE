/*
 * CSkreen.h
 *
 *  Created on: 11 ���. 2019 �.
 *      Author: Acer
 */

#pragma once
#define CSKREEN_H_
#include "CBasicSkreen.h"
#include "CAgent.h"
#include <iostream>
using namespace std;
class CSkreen:public CBasicSkreen
{
public:


	CSkreen();

	void ScreenAgent(const CAgent & agent);
	void ShowFooter() {
					cout << "view: 1" << endl << endl;
	}
	~CSkreen();
};
